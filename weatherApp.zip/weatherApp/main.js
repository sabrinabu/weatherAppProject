 
 //api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}
 const weatherApi={
     key:"9f336626c2fe261ca4a5a53639e7fe65",
     baseUrl:"https://api.openweathermap.org/data/2.5/weather"
 }


const searchInputBox=document.getElementById("input-box");
searchInputBox.addEventListener('keypress',(ev)=>{
    if(ev.keyCode==13){
        console.log(searchInputBox.value);
        getWeatherReport(searchInputBox.value);
    }
  
});
//get weather Report
function getWeatherReport(city){
    fetch(`${weatherApi.baseUrl}?q=${city}&appid=${weatherApi.key}&units=mertic`)
    .then(weather =>{
        return weather.json();
    }).then(showWeather);

}

function showWeather(weather){
   console.log(weather); 
   let city = document.getElementById("city");
   city.innerText=`${weather.name},${weather.sys.country}`;
   let temp= document.getElementById("temp");
   temp.innerHTML=`${Math.round(weather.main.temp-273.15)}&deg;c`;
   let minMaxTemp=document.getElementById("min-max");
   minMaxTemp.innerHTML=`${Math.floor(weather.main.temp_min-273.15)}&deg;c (min)/,${Math.ceil(weather.main.temp_max-273.15)}&deg;c (max)`;
   let weatherType=document.getElementById("weather");
   weatherType.innerText=`${weather.weather[0].main }`;
   let date = document.getElementById("date");
   let todaDate= new Date();
   date.innerText= dataManage(todaDate);

   if(weatherType.textContent =='Clear'){
       document.body.style.backgroundImage="url('image/clear.jpg')";
   }
   else if(weatherType.textContent =='Clouds'){
    document.body.style.backgroundImage="url('image/cloud.jpg')";
}
 else if(weatherType.textContent =='Rain'){
    document.body.style.backgroundImage="url('image/rain.jpg')";
}
else if(weatherType.textContent =='Haze'){
    document.body.style.backgroundImage="url('image/haze.jpg')";
}
}

function dataManage(dateArg){
  let days=["Sunday", "Monday","Tuesday",">Wednesday","Thursday","Friday","Saturday"];
  let months=["January","February","March","April","May","June","July","August","September","October","November","December"];

  let year =dateArg.getFullYear();
  let month =months[dateArg.getMonth()];
  let date=dateArg.getDate();
  let day=days[dateArg.getDay()];
  return `${date} ${month} (${day}) ${year}`;
}